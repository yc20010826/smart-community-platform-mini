
export const baseConfig = {
	imgUrl:"https://yktc.wangyunzhi.cn/",
	baseUrl:"https://yktc.wangyunzhi.cn/"
}

export default baseConfig